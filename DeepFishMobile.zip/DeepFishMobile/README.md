# DeepFish Mobile (Android, personal use)

Original rewrite of the *idea* of the PC macro (colour-based shake detection + PD reel control). Not for redistribution.

## Build
A) Android Studio: Open this folder -> wait for Gradle sync -> Build > Build APK(s). Copy app-debug.apk to the phone.
B) No Android Studio: push this folder to a PRIVATE GitHub repo -> Actions tab -> "build" -> download artifact "apk".

## Setup on the phone
1. Install the APK. Android 13+: Settings > Apps > DeepFish Mobile > ⋮ > "Allow restricted settings".
2. Open app: (1) enable accessibility service, (2) allow draw-over-apps, (3) Start -> accept screen capture.
3. Open Roblox (landscape), equip your rod yourself. A floating ▶ / 📷 appears top-right.
4. 📷 saves a screenshot to Pictures/DeepFish. Read exact hex colours from it with any colour-picker app
   (shake button colour, fish colour, bar colour) and put them in the settings. Adjust % areas the same way.
5. ▶ starts / ■ stops the loop.

## Not ported from the PC version
Perfect-cast, special rods, totems, aquarium, keeper, webhook, auto graphics/camera setup, profiles.
