package app.fishm

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Touch injection. tap() = blocking tap/long-press. setHold() = "mouse down/up" for the reel minigame,
 *  implemented as one continued stroke made of short slices so it can be released within ~SLICE ms. */
class TapService : AccessibilityService() {
    companion object {
        @Volatile var inst: TapService? = null
        const val SLICE = 40L
    }
    private val main = Handler(Looper.getMainLooper())
    private var stroke: StrokeDescription? = null
    private var active = false
    @Volatile private var wantDown = false
    @Volatile private var px = 0f
    @Volatile private var py = 0f

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Call from a background thread only. */
    fun tap(x: Float, y: Float, ms: Long) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder()
            .addStroke(StrokeDescription(Path().apply { moveTo(x, y) }, 0, ms)).build()
        main.post {
            val cb = object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }
            if (!dispatchGesture(g, cb, null)) latch.countDown()
        }
        latch.await(ms + 2000, TimeUnit.MILLISECONDS)
    }

    fun setHold(down: Boolean, x: Float = px, y: Float = py) {
        px = x; py = y; wantDown = down
        main.post { if (wantDown && !active) begin() }
    }

    private fun path() = Path().apply { moveTo(px, py) }
    private fun begin() { active = true; send(StrokeDescription(path(), 0, SLICE, true)) }
    private fun send(s: StrokeDescription) {
        stroke = s
        val cb = object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { next(s.willContinue()) }
            override fun onCancelled(d: GestureDescription?) { next(false) }
        }
        if (!dispatchGesture(GestureDescription.Builder().addStroke(s).build(), cb, null)) active = false
    }
    private fun next(continued: Boolean) {
        if (continued) {
            val s = stroke ?: return
            if (wantDown) send(s.continueStroke(path(), 0, SLICE, true))
            else send(s.continueStroke(path(), 0, 1, false))   // final tiny slice = release
        } else {
            active = false
            if (wantDown) begin()
        }
    }
}
