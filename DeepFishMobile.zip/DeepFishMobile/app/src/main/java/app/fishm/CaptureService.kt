package app.fishm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class Frame(private val img: Image) {
    val w = img.width
    val h = img.height
    private val pl = img.planes[0]
    private val buf = pl.buffer
    private val rs = pl.rowStride
    private val ps = pl.pixelStride
    fun rgb(x: Int, y: Int): Int {
        val i = y * rs + x * ps
        return ((buf.get(i).toInt() and 255) shl 16) or ((buf.get(i + 1).toInt() and 255) shl 8) or (buf.get(i + 2).toInt() and 255)
    }
    fun bitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(rs / ps, h, Bitmap.Config.ARGB_8888)
        buf.rewind(); bmp.copyPixelsFromBuffer(buf)
        return Bitmap.createBitmap(bmp, 0, 0, w, h)
    }
    fun close() = img.close()
}

class CaptureService : Service() {
    var w = 0
    var h = 0
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    @Volatile private var bot: FishBot? = null
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Config.init(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("fish", "DeepFish", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "fish").setContentTitle("DeepFish Mobile")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        proj = p
        val dm = resources.displayMetrics
        w = maxOf(dm.widthPixels, dm.heightPixels)   // Roblox runs landscape
        h = minOf(dm.widthPixels, dm.heightPixels)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay("fish", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        showOverlay()
        return START_NOT_STICKY
    }

    /** Newest unseen frame or null. Caller must close(). */
    fun frame(): Frame? = try { reader?.acquireLatestImage()?.let { Frame(it) } } catch (e: Exception) { null }

    fun waitFrame(ms: Long): Frame? {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { frame()?.let { return it }; Thread.sleep(40) }
        return null
    }

    fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    private fun showOverlay() {
        val m = getSystemService(WindowManager::class.java); wm = m
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "▶"; setOnClickListener { toggle(this) } })
        row.addView(Button(this).apply { text = "📷"; setOnClickListener { shot() } })
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; alpha = 0.7f }
        m.addView(row, lp); overlay = row
    }

    private fun toggle(b: Button) {
        val cur = bot
        if (cur != null && cur.isAlive) { cur.running = false; bot = null; b.text = "▶" }
        else { bot = FishBot(this).also { it.start() }; b.text = "■" }
    }

    /** Saves the current game frame to Pictures/DeepFish so you can read exact colors from it. */
    private fun shot() {
        Thread {
            val f = waitFrame(2500)
            if (f == null) { toast("No frame yet"); return@Thread }
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "fish_${System.currentTimeMillis()}.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DeepFish")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { f.bitmap().compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast("Saved to Pictures/DeepFish")
            } finally { f.close() }
        }.start()
    }

    override fun onDestroy() {
        bot?.running = false
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
