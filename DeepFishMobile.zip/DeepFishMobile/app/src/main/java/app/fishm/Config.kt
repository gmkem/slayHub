package app.fishm

import android.content.Context
import android.content.SharedPreferences
import kotlin.math.abs

fun near(a: Int, b: Int, t: Int) =
    abs((a shr 16 and 255) - (b shr 16 and 255)) <= t &&
    abs((a shr 8 and 255) - (b shr 8 and 255)) <= t &&
    abs((a and 255) - (b and 255)) <= t

/** Defaults for the minigame strip / colors are taken from the PC macro (percent of screen). */
object Config {
    class F(val key: String, val label: String, val def: String)
    val fields = listOf(
        F("castX", "Cast: hold X %", "50"), F("castY", "Cast: hold Y %", "50"),
        F("castHoldMs", "Cast: hold time ms", "1000"), F("bobberWaitMs", "Wait after cast ms", "1000"),
        F("shakeL", "Shake area left %", "21"), F("shakeR", "Shake area right %", "79"),
        F("shakeT", "Shake area top %", "25"), F("shakeB", "Shake area bottom %", "88"),
        F("shakeColor", "Shake button color hex (blank = tap area center)", ""),
        F("shakeTol", "Shake color tolerance", "12"), F("shakeDelayMs", "Shake loop delay ms", "60"),
        F("shakeFailsafeS", "Shake failsafe seconds", "30"),
        F("barL", "Minigame strip left %", "30.2"), F("barR", "Minigame strip right %", "69.8"),
        F("barT", "Minigame strip top %", "84.2"), F("barB", "Minigame strip bottom %", "86.9"),
        F("fishColor", "Fish color hex", "434B5B"), F("barColor", "Bar color hex", "F1F1F1"),
        F("barTol", "Minigame color tolerance", "10"),
        F("holdX", "Reel: hold X %", "50"), F("holdY", "Reel: hold Y %", "60"),
        F("leadMs", "Reel: lead (stopping distance) ms", "120"),
        F("restartMs", "Delay between casts ms", "1500")
    )
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private fun def(k: String) = fields.first { it.key == k }.def
    fun s(k: String): String = sp.getString(k, null) ?: def(k)
    fun set(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun d(k: String): Double = s(k).trim().toDoubleOrNull() ?: def(k).toDouble()
    fun f(k: String): Float = d(k).toFloat()
    fun hex(k: String): Int = s(k).trim().removePrefix("#").removePrefix("0x").toIntOrNull(16) ?: -1
}
