package app.fishm

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val boxes = LinkedHashMap<String, EditText>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Config.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun btn(t: String, a: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1. Enable accessibility (DeepFish Mobile)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Allow draw-over-apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Start (screen capture + floating ▶ / 📷)") {
            save()
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        }
        btn("Stop") { stopService(Intent(this, CaptureService::class.java)) }
        Config.fields.forEach { f ->
            col.addView(TextView(this).apply { text = f.label })
            val e = EditText(this).apply { setText(Config.s(f.key)); isSingleLine = true }
            boxes[f.key] = e; col.addView(e)
        }
        btn("Save settings") { save() }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun save() { boxes.forEach { (k, e) -> Config.set(k, e.text.toString()) } }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null)
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data))
    }
}
