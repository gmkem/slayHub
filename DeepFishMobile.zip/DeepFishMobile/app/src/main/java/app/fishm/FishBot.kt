package app.fishm

import kotlin.math.abs
import kotlin.math.max

/** Loop: cast -> shake -> reel minigame -> repeat. Reel control is a rewrite of the PC macro's idea:
 *  read fish/bar positions from pixel colors, estimate velocities, PD duty-cycle inside the bar,
 *  predictive bang-bang outside it. */
class FishBot(private val svc: CaptureService) : Thread() {
    @Volatile var running = true
    private class Scan(val fish: Float, val l: Float, val r: Float)

    private var W = 0; private var H = 0
    private var fishC = 0; private var barC = 0; private var tol = 10
    private var bx0 = 0f; private var bx1 = 0f; private var by0 = 0f; private var by1 = 0f

    private fun nap(ms: Long) { try { sleep(ms) } catch (_: InterruptedException) {} }

    private fun load() {
        W = svc.w; H = svc.h
        fishC = Config.hex("fishColor"); barC = Config.hex("barColor"); tol = Config.d("barTol").toInt()
        bx0 = W * Config.f("barL") / 100f; bx1 = W * Config.f("barR") / 100f
        by0 = H * Config.f("barT") / 100f; by1 = H * Config.f("barB") / 100f
    }

    override fun run() {
        val tap = TapService.inst
        if (tap == null) { svc.toast("Enable the accessibility service first"); return }
        try {
            while (running) {
                load()
                tap.tap(W * Config.f("castX") / 100f, H * Config.f("castY") / 100f, Config.d("castHoldMs").toLong())
                nap(Config.d("bobberWaitMs").toLong())
                if (running && shake(tap)) reel(tap)
                tap.setHold(false)
                nap(Config.d("restartMs").toLong())
            }
        } finally { tap.setHold(false) }
    }

    private fun shake(tap: TapService): Boolean {
        val sl = W * Config.f("shakeL") / 100f; val sr = W * Config.f("shakeR") / 100f
        val st = H * Config.f("shakeT") / 100f; val sb = H * Config.f("shakeB") / 100f
        val sc = Config.hex("shakeColor"); val stol = Config.d("shakeTol").toInt()
        val delay = Config.d("shakeDelayMs").toLong()
        val end = System.currentTimeMillis() + Config.d("shakeFailsafeS").toLong() * 1000
        while (running && System.currentTimeMillis() < end) {
            val f = svc.frame()
            if (f != null) {
                var tx = -1f; var ty = -1f
                try {
                    if (scan(f) != null) return true          // minigame appeared
                    if (sc >= 0) { find(f, sc, stol, sl, st, sr, sb)?.let { tx = it.first; ty = it.second } }
                    else { tx = (sl + sr) / 2; ty = (st + sb) / 2 }
                } finally { f.close() }
                if (tx >= 0) tap.tap(tx, ty, 30)
            }
            nap(delay)
        }
        return false
    }

    private fun find(f: Frame, col: Int, t: Int, l: Float, tp: Float, r: Float, b: Float): Pair<Float, Float>? {
        var n = 0; var sx = 0L; var sy = 0L; var fx = -1; var fy = -1
        var y = tp.toInt()
        while (y < b.toInt() && y < f.h) {
            var x = l.toInt()
            while (x < r.toInt() && x < f.w) {
                if (near(f.rgb(x, y), col, t)) {
                    if (fx < 0) { fx = x; fy = y }
                    if (abs(x - fx) < 80 && abs(y - fy) < 80) { sx += x; sy += y; n++ }
                }
                x += 4
            }
            y += 4
        }
        return if (n == 0) null else Pair(sx.toFloat() / n, sy.toFloat() / n)
    }

    private fun scan(f: Frame): Scan? {
        var fn = 0; var fs = 0L; var bn = 0; var bl = Int.MAX_VALUE; var br = -1
        var y = by0.toInt()
        while (y <= by1.toInt() && y < f.h) {
            var x = bx0.toInt()
            while (x <= bx1.toInt() && x < f.w) {
                val c = f.rgb(x, y)
                if (near(c, fishC, tol)) { fn++; fs += x }
                else if (near(c, barC, tol)) { bn++; if (x < bl) bl = x; if (x > br) br = x }
                x += 2
            }
            y += 3
        }
        return if (fn < 3 || bn < 10) null else Scan(fs.toFloat() / fn, bl.toFloat(), br.toFloat())
    }

    private fun reel(tap: TapService) {
        val hx = W * Config.f("holdX") / 100f; val hy = H * Config.f("holdY") / 100f
        val lead = Config.f("leadMs") / 1000f
        val sc = 2560f / W
        val kp = 0.0122f * sc; val kd = 0.00488f * sc
        var prevT = 0L; var pBar = 0f; var pFish = 0f; var barV = 0f; var fishV = 0f
        var bias = 0f; var acc = 0f; var down = false; var lastDown = false
        var lastSeen = System.currentTimeMillis()
        while (running) {
            val f = svc.frame()
            if (f == null) {
                if (System.currentTimeMillis() - lastSeen > 2000) break
                nap(3); continue
            }
            val s = try { scan(f) } finally { f.close() }
            val ms = System.currentTimeMillis()
            if (s == null) { if (ms - lastSeen > 2000) break; continue }   // keeps current hold state
            lastSeen = ms
            val now = System.nanoTime()
            val c = (s.l + s.r) / 2; val half = (s.r - s.l) / 2
            val err = c - s.fish                    // >0: bar is right of fish -> release
            if (prevT > 0) {
                val dt = (now - prevT) / 1e9f
                if (dt > 0.002f) {
                    val rb = (c - pBar) / dt
                    var rf = (s.fish - pFish) / dt
                    if (abs(s.fish - pFish) > 100) { rf = 0f; fishV = 0f }
                    barV = 0.6f * rb + 0.4f * barV; fishV = 0.6f * rf + 0.4f * fishV
                    if (dt < 0.1f) bias = (bias - 0.25f * kp * err * dt).coerceIn(-0.2f, 0.2f)
                    pBar = c; pFish = s.fish; prevT = now
                }
            } else { pBar = c; pFish = s.fish; prevT = now }
            val rel = barV - fishV
            val reachL = bx0 + half; val reachR = bx1 - half
            down = when {
                s.fish < reachL -> false
                s.fish > reachR -> true
                s.fish >= s.l && s.fish <= s.r -> {      // fish inside bar: PD duty cycle
                    val duty = (0.463f + bias - kp * err - kd * rel).coerceIn(0f, 1f)
                    acc += duty
                    if (acc >= 1f) { acc -= 1f; true } else false
                }
                else -> {                                // fish outside: predictive bang-bang
                    val sigma = err + rel * lead
                    val dead = max(2f, half * 0.04f)
                    if (sigma > dead) false else if (sigma < -dead) true else down
                }
            }
            if (down != lastDown) { tap.setHold(down, hx, hy); lastDown = down }
        }
    }
}
